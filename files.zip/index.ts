/**
 * @author Nome Completo do Autor
 * @ra 000000
 *
 * Exportações do módulo de usuários.
 * Este arquivo é importado pelo index.ts raiz do Firebase Functions.
 */

export { cadastrarUsuario } from "./handlers/cadastrarUsuario";
